﻿using System;
namespace Day2Lab2;
class program
{
    static void Main(String[] args)
    {
        int num = 100;                  //Question # 1
        while (num <= 200)
        {
            Console.WriteLine(num);
            num++;
        }

        int[] arr = {1,2,3,45,5};         //Question No 2
        for (int i = 0; i < arr.Length; i++)
        {
            Console.WriteLine(arr[i]);
        }

        int[] arr1 = {1,2,3,7,8,6};         //Question No 3
        for (int i = arr1.Length - 1; i >= 0; i--)
        {
            Console.WriteLine(arr1[i]);
        }

        int sum = 0;                       //Question No 4
        int[] arr2 = { 1, 2, 3, 4, 5, 6 };
        for (int i = 0; i < arr2.Length; i++)
        {
            sum = sum + arr2[i];
        }
        Console.WriteLine(sum);

        int i;                             //Question No 5
        for (i= 1; i <= 20; i++)
        {
            if (i != 9 && i != 11)
            {
                Console.WriteLine(i);
            }
        }


        int[] arr4 = { 1, 2, 3, 4, 5, 6 };     //Question No 6
        foreach (int i in arr4)
        {
            Console.WriteLine(i);
        }

        int sum = 0;                             //Question No 7
        float avg;
        int[] arr7 = { 1, 2, 3, 4, 5, 6 };
        for (int i = 0; i < arr7.Length; i++)
        {
            sum = sum + arr7[i];
        }
        avg = sum / arr7.Length;
        Console.WriteLine(avg);
        Console.WriteLine(sum);

    }
}
